// Import statements go here.  For example,
// import java.awt.Color;
// import java.util.ArrayList;
// import java.util.Random;

/**
 *  Lab (or Programming Project) X: Name of Lab or PP<br>
 *
 *  The <code>MainClassTemplate</code> class provides a main method
 *  for a program that does X.
 *
 *  A more detailed description goes here, if necessary.
 *
 *  @author [your name]
 *  @author [your partner's name]
 *  @author [with assistance from ... (including instructor/TAs)]
 *  @author [working side-by-side with ...]
 *  @version [last_modification_date]
 */
public class MainClassTemplate
{
    /**
     *  The main function initiates execution of this program.
     *    @param    String[] args not used in this program
     *              (but main methods always need this parameter)
     **/
    public static void main(String[] args)
    {
        System.out.println ("Welcome to Programming Project X.");

        // Construct one or more objects, then invoke one or more
        // methods to get the program started.  For example:
        //   SomeClass obj = new SomeClass(someParameter);
        //   obj.modifyObject(aDifferentParameter);
        //   int anInteger = obj.getSomeIntAttribute();

        System.out.println ("Program done.");

    }//end main

}//end class
